int set_fpe_x87(void);
int set_fpe_x87_sse(void);
int clear_fpe_x87_sse(void);
